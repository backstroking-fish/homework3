#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<windows.h>
#include<time.h>
#include<graphics.h>
#include<mmsystem.h>
#pragma comment(lib,"Winmm.lib")
IMAGE img00, img01, img02, img03, img04, img11, img21, img31, img41, img51, img61, img71, img81, img91, img101, img111, img121, img131, img040,img12, img22, img32, img42, img52, img62, img72, img82, img92, img102, img112, img122, img132 ;
MOUSEMSG msg2;
void setinitbk()//���ÿ�ʼ����
{
	initgraph(1422, 800);
	loadimage(&img00, "images/tdd.jpg", 1422, 800);//����
	putimage(0, 0, &img00);

	loadimage(&img01, "images/01.jpg", 300, 75);//����
	putimage(100, 70, &img01);

	loadimage(&img02, "images/02.jpg", 300, 75);
	putimage(100, 270, &img02); 

	loadimage(&img03, "images/03.jpg", 300, 75);
	putimage(100, 500, &img03);

	loadimage(&img04, "images/04.jpg", 400, 75);
	putimage(50, 675, &img04); 

	loadimage(&img11, "images/11.jpg", 200, 50);//������
	putimage(550, 40, &img11);

	loadimage(&img21, "images/21.jpg", 200, 50);
	putimage(770, 40, &img21);

	loadimage(&img31, "images/31.jpg", 200, 50);
	putimage(550, 110, &img31);

	loadimage(&img41, "images/41.jpg", 200, 50);
	putimage(770, 110, &img41);

	loadimage(&img51, "images/51.jpg", 300, 50);//Ӳ��
	putimage(550, 230, &img51);

	loadimage(&img61, "images/61.jpg", 300, 50);
	putimage(550, 300, &img61);

	loadimage(&img71, "images/71.jpg", 300, 50);
	putimage(550, 370, &img71);

	loadimage(&img81, "images/81.jpg", 200, 50);//����
	putimage(550, 490, &img81);

	loadimage(&img91, "images/91.jpg", 200, 50);
	putimage(770, 490, &img91);

	loadimage(&img101, "images/101.jpg", 200, 50);
	putimage(990, 490, &img101);

	loadimage(&img111, "images/111.jpg", 200, 50);
	putimage(550, 560, &img111);

	loadimage(&img121, "images/121.jpg", 150, 50);
	putimage(770, 560, &img121);

	loadimage(&img131, "images/131.jpg", 200, 50);
	putimage(990, 560, &img131);
	while (1)
	{
		if (MouseHit())
		{
			msg2 = GetMouseMsg();
			if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 550 && msg2.x <= 750 && msg2.y >= 40 && msg2.y <= 90)//����
			{
				initgraph(1422, 800);
				loadimage(&img12, "images/12.jpg", 1422, 800);
				putimage(0, 0, &img12);
				_getch();
				break;
			}

			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 770 && msg2.x <= 790 && msg2.y >= 40 && msg2.y <= 90)
			{
				initgraph(1422, 800);
				loadimage(&img22, "images/22.jpg", 1422, 800);
				putimage(0, 0, &img22);
				_getch();
				break;
			}
			
			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 550 && msg2.x <= 750 && msg2.y >= 110 && msg2.y <= 160)
			{
				initgraph(1422, 800);
				loadimage(&img32, "images/32.jpg", 1422, 800);
				putimage(0, 0, &img32);
				_getch();
				break;
			}

			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 770 && msg2.x <= 970 && msg2.y >= 110 && msg2.y <= 160)
			{
				initgraph(1422, 800);
				loadimage(&img42, "images/42.jpg", 1422, 800);
				putimage(0, 0, &img42);
				_getch();
				break;
			}

			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 550 && msg2.x <= 850 && msg2.y >= 230 && msg2.y <= 280)//Ӳ��
			{
				initgraph(1422, 800);
				loadimage(&img52, "images/52.jpg", 1422, 800);
				putimage(0, 0, &img52);
				_getch();
				break;
			}

			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 550 && msg2.x <= 850 && msg2.y >= 300 && msg2.y <= 350)
			{
				initgraph(1422, 800);
				loadimage(&img62, "images/62.jpg", 1422, 800);
				putimage(0, 0, &img62);
				_getch();
				break;
			}

			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 550 && msg2.x <= 850 && msg2.y >= 370 && msg2.y <= 420)
			{
				initgraph(1422, 800);
				loadimage(&img72, "images/72.jpg", 1422, 800);
				putimage(0, 0, &img72);
				_getch();
				break;
			}

			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 550 && msg2.x <= 750 && msg2.y >= 490 && msg2.y <= 540)//����
			{
				initgraph(1422, 800);
				loadimage(&img82, "images/82.jpg", 1422, 800);
				putimage(0, 0, &img82);
				_getch();
				break;
			}

			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 770 && msg2.x <= 970 && msg2.y >= 490 && msg2.y <= 540)
			{
				initgraph(1422, 800);
				loadimage(&img92, "images/92.jpg", 1422, 800);
				putimage(0, 0, &img92);
				_getch();
				break;
			}

			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 990 && msg2.x <= 1190 && msg2.y >= 490 && msg2.y <= 540)
			{
				initgraph(1422, 800);
				loadimage(&img102, "images/102.jpg", 1422, 800);
				putimage(0, 0, &img102);
				_getch();
				break;
			}

			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 550 && msg2.x <= 750 && msg2.y >= 560 && msg2.y <= 610)
			{
				initgraph(1422, 800);
				loadimage(&img112, "images/112.jpg", 1422, 800);
				putimage(0, 0, &img112);
				_getch();
				break;
			}

			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 770 && msg2.x <= 920 && msg2.y >= 560 && msg2.y <= 610)
			{
			initgraph(1422, 800);
			loadimage(&img122, "images/122.jpg", 1422, 800);
			putimage(0, 0, &img122);
			_getch();
			break;
			}

			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 990 && msg2.x <= 1190 && msg2.y >= 560 && msg2.y <= 610)
			{
			initgraph(1422, 800);
			loadimage(&img132, "images/132.jpg", 1422, 800);
			putimage(0, 0, &img132);
			_getch();
			break;
			}

			else if (msg2.uMsg == WM_LBUTTONDOWN && msg2.x >= 50 && msg2.x <= 750 && msg2.y >= 675 && msg2.y <= 775)//������ʶ
			{
				initgraph(1422, 800);
				loadimage(&img040, "images/040.jpg", 1422, 800);
				putimage(0, 0, &img040);
				_getch();
				break;
			}
		}
	}
}

int main()
{
	while (1)
	{
        setinitbk();
	}
	return 0;
}